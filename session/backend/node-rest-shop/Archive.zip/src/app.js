const express = require("express");
const morgan = require("morgan");
const bodyParser = require("body-parser");
require("dotenv").config();
const { checkAuth } = require("./middleware/checkAuth");

//@ DB Connection:
require("./config/database");

//@ Import Routes:
const usersRouter = require("./routes/users.routes");
const productsRouter = require("./routes/products.routes");
const ordersRouter = require("./routes/orders.routes");

const app = express();

app.use(morgan("dev"));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//@ Setup Router

app.use("/users", usersRouter);
app.use("/products", productsRouter);
app.use("/orders", checkAuth, ordersRouter);

const PORT = process.env.PORT;

app.listen(PORT, () => {
  console.log("Server is listening on port:", PORT);
});
